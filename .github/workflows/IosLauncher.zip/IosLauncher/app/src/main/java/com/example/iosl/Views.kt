package com.example.iosl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/** صفحات أفقية مع تثبيت (snap) بدون أي مكتبة */
class Pager(ctx: Context) : HorizontalScrollView(ctx) {
    val row = LinearLayout(ctx)
    var onScroll: ((Int, Int) -> Unit)? = null
    var onPage: ((Int) -> Unit)? = null
    private var startPage = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isFillViewport = true
        row.orientation = LinearLayout.HORIZONTAL
        addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    fun pageCount(): Int = row.childCount

    fun currentPage(): Int =
        if (width == 0) 0 else ((scrollX + width / 2) / width).coerceIn(0, maxOf(0, pageCount() - 1))

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScroll?.invoke(l, width)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) startPage = currentPage()
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val r = super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) snap()
        return r
    }

    private fun snap() {
        if (width == 0) return
        val d = scrollX - startPage * width
        var target = startPage
        if (d > width * 0.18f) target++ else if (d < -width * 0.18f) target--
        target = target.coerceIn(0, maxOf(0, pageCount() - 1))
        smoothScrollTo(target * width, 0)
        onPage?.invoke(target)
    }
}

/** شبكة ثابتة الأعمدة والصفوف، كل خلية بنفس الحجم */
class HomePage(ctx: Context, private val cols: Int, private val rows: Int) : ViewGroup(ctx) {
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = View.MeasureSpec.getSize(wSpec)
        val h = View.MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        val cw = (w - paddingLeft - paddingRight) / cols
        val ch = (h - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(ch, View.MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (width - paddingLeft - paddingRight) / cols
        val ch = (height - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val rr = i / cols
            val cc = i % cols
            if (rr >= rows) break
            val x = paddingLeft + cc * cw
            val y = paddingTop + rr * ch
            getChildAt(i).layout(x, y, x + cw, y + ch)
        }
    }
}

/** أيقونة تطبيق أو معاينة مجلد 3x3 */
class IconView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
    var folder = false
    var inset = 0f
    val minis = arrayOfNulls<Bitmap>(9)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(120, 235, 235, 242) }
    private val dst = RectF()

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat() - 2 * inset
        val x0 = (width - s) / 2f
        val y0 = (height - s) / 2f
        if (folder) {
            val r = s * 0.2237f
            c.drawRoundRect(x0, y0, x0 + s, y0 + s, r, r, bg)
            val pad = s * 0.12f
            val gap = s * 0.05f
            val m = (s - 2 * pad - 2 * gap) / 3f
            for (i in 0 until 9) {
                val b = minis[i] ?: continue
                val x = x0 + pad + (i % 3) * (m + gap)
                val y = y0 + pad + (i / 3) * (m + gap)
                dst.set(x, y, x + m, y + m)
                c.drawBitmap(b, null, dst, paint)
            }
        } else {
            val b = bmp ?: return
            dst.set(x0, y0, x0 + s, y0 + s)
            c.drawBitmap(b, null, dst, paint)
        }
    }
}

class Dots(ctx: Context) : View(ctx) {
    private var count = 0
    private var cur = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val d = ctx.resources.displayMetrics.density

    fun set(c: Int, i: Int) { count = c; cur = i; invalidate() }

    override fun onDraw(c: Canvas) {
        if (count < 2) return
        val gap = 14 * d
        val r = 3.5f * d
        val start = width / 2f - (count - 1) * gap / 2f
        for (i in 0 until count) {
            p.alpha = if (i == cur) 255 else 100
            c.drawCircle(start + i * gap, height / 2f, r, p)
        }
    }
}
