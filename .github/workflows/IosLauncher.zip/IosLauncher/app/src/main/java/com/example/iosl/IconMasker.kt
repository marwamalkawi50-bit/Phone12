package com.example.iosl

import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/** يحوّل أي أيقونة (حديثة أو قديمة) إلى مربع بزوايا iOS بنفس الشكل. */
object IconMasker {
    private const val CORNER = 0.2237f // نسبة زوايا iOS

    fun render(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = size * CORNER
        c.clipPath(Path().apply {
            addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, Path.Direction.CW)
        })
        if (d is AdaptiveIconDrawable) {
            // الأيقونة 108dp والظاهر منها 72dp، نمدّد الحدود لتملأ المربع
            val pad = (size * (108f / 72f - 1f) / 2f).toInt()
            d.background?.apply { setBounds(-pad, -pad, size + pad, size + pad); draw(c) }
            d.foreground?.apply { setBounds(-pad, -pad, size + pad, size + pad); draw(c) }
        } else {
            // أيقونة قديمة: خلفية بلون الأيقونة المتوسط + الأيقونة في الوسط
            c.drawColor(avgColor(d))
            val inset = (size * 0.16f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }
        return bmp
    }

    private fun avgColor(d: Drawable): Int {
        val s = 24
        val tmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(tmp))
        var rr = 0L; var gg = 0L; var bb = 0L; var n = 0L
        for (y in 0 until s) for (x in 0 until s) {
            val p = tmp.getPixel(x, y)
            if (Color.alpha(p) > 128) { rr += Color.red(p); gg += Color.green(p); bb += Color.blue(p); n++ }
        }
        tmp.recycle()
        return if (n == 0L) Color.DKGRAY else Color.rgb((rr / n).toInt(), (gg / n).toInt(), (bb / n).toInt())
    }
}
