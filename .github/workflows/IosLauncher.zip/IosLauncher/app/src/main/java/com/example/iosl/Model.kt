package com.example.iosl

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

class App(val key: String, val pkg: String, val label: String, val category: Int, val intent: Intent)

/** name == null  => تطبيق مفرد (keys فيه عنصر واحد)، غير ذلك => مجلد */
class Entry(var name: String?, val keys: MutableList<String>) {
    val isFolder: Boolean get() = name != null
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("layout_v2", Context.MODE_PRIVATE)
    var dock = mutableListOf<String>()
    var pages = mutableListOf<MutableList<Entry>>()
    var hidden = mutableSetOf<String>()
    var fresh = true

    init { load() }

    private fun strList(a: JSONArray): MutableList<String> {
        val l = mutableListOf<String>()
        for (i in 0 until a.length()) l.add(a.getString(i))
        return l
    }

    private fun load() {
        val s = sp.getString("data", null) ?: return
        try {
            val o = JSONObject(s)
            val d = strList(o.getJSONArray("dock"))
            val h = strList(o.getJSONArray("hidden"))
            val ps = mutableListOf<MutableList<Entry>>()
            val pa = o.getJSONArray("pages")
            for (i in 0 until pa.length()) {
                val ea = pa.getJSONArray(i)
                val page = mutableListOf<Entry>()
                for (j in 0 until ea.length()) {
                    val eo = ea.getJSONObject(j)
                    val n: String? = if (eo.has("n")) eo.getString("n") else null
                    page.add(Entry(n, strList(eo.getJSONArray("k"))))
                }
                ps.add(page)
            }
            dock = d
            hidden = h.toMutableSet()
            pages = ps
            fresh = false
        } catch (ex: Exception) {
        }
    }

    fun save() {
        val o = JSONObject()
        o.put("dock", JSONArray(dock))
        o.put("hidden", JSONArray(hidden.toList()))
        val pa = JSONArray()
        for (p in pages) {
            val ea = JSONArray()
            for (e in p) {
                val eo = JSONObject()
                val n = e.name
                if (n != null) eo.put("n", n)
                eo.put("k", JSONArray(e.keys))
                ea.put(eo)
            }
            pa.put(ea)
        }
        o.put("pages", pa)
        sp.edit().putString("data", o.toString()).apply()
    }

    private fun appendEntry(e: Entry, cap: Int) {
        val l: MutableList<Entry> = pages.lastOrNull()?.takeIf { it.size < cap }
            ?: mutableListOf<Entry>().also { pages.add(it) }
        l.add(e)
    }

    private fun single(k: String) = Entry(null, mutableListOf(k))

    private fun tidy() {
        pages.removeAll { it.isEmpty() }
        if (pages.isEmpty()) pages.add(mutableListOf())
    }

    private fun removeEverywhere(key: String) {
        dock.remove(key)
        hidden.remove(key)
        for (p in pages) {
            val iter = p.iterator()
            while (iter.hasNext()) {
                val e = iter.next()
                if (e.keys.remove(key) && e.keys.isEmpty()) iter.remove()
            }
        }
    }

    fun reconcile(valid: Set<String>, ordered: List<String>, defDock: List<String>, cap: Int) {
        if (fresh) {
            dock = defDock.filter { it in valid }.take(4).toMutableList()
            fresh = false
        }
        dock.retainAll(valid)
        hidden.retainAll(valid)
        for (p in pages) {
            val iter = p.iterator()
            while (iter.hasNext()) {
                val e = iter.next()
                e.keys.retainAll(valid)
                if (e.keys.isEmpty()) iter.remove()
            }
        }
        val placed = HashSet<String>()
        placed.addAll(dock)
        placed.addAll(hidden)
        for (p in pages) for (e in p) placed.addAll(e.keys)
        for (k in ordered) if (k !in placed) appendEntry(single(k), cap)
        tidy()
        save()
    }

    fun folderOf(key: String): Entry? {
        for (p in pages) for (e in p) if (e.isFolder && key in e.keys) return e
        return null
    }

    fun folders(): List<Entry> = pages.flatMap { p -> p.filter { it.isFolder } }

    fun addToDock(k: String) {
        if (dock.size >= 4) return
        removeEverywhere(k); dock.add(k); tidy(); save()
    }

    fun removeFromDock(k: String, cap: Int) {
        dock.remove(k); appendEntry(single(k), cap); tidy(); save()
    }

    fun hide(k: String) {
        removeEverywhere(k); hidden.add(k); tidy(); save()
    }

    fun unhide(k: String, cap: Int) {
        hidden.remove(k); appendEntry(single(k), cap); tidy(); save()
    }

    fun moveOut(k: String, cap: Int) {
        removeEverywhere(k); appendEntry(single(k), cap); tidy(); save()
    }

    fun makeFolder(k: String, name: String, cap: Int) {
        for (p in pages) for (e in p) {
            if (!e.isFolder && e.keys.size == 1 && e.keys[0] == k) {
                e.name = name; save(); return
            }
        }
        removeEverywhere(k)
        appendEntry(Entry(name, mutableListOf(k)), cap)
        tidy(); save()
    }

    fun addToFolder(k: String, f: Entry) {
        removeEverywhere(k); f.keys.add(k); tidy(); save()
    }

    fun dissolve(e: Entry, cap: Int) {
        for (p in pages) p.remove(e)
        for (k in e.keys) appendEntry(single(k), cap)
        tidy(); save()
    }
}
