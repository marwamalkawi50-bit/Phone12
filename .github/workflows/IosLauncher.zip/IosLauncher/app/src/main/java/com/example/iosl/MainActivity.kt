package com.example.iosl

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private data class App(val label: String, val pkg: String, val intent: Intent)

    private val pool = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = LruCache<String, Bitmap>(120)
    private var apps = listOf<App>()
    private lateinit var grid: GridView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(18)
            setPadding(dp(12), dp(56), dp(12), dp(24))
            clipToPadding = false
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnItemClickListener { _, _, i, _ -> startActivity(apps[i].intent) }
            setOnItemLongClickListener { _, _, i, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + apps[i].pkg)))
                true
            }
        }
        setContentView(grid)
        grid.adapter = Adapter()
    }

    override fun onResume() {
        super.onResume()
        pool.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    App(it.loadLabel(pm).toString(), it.activityInfo.packageName,
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(it.activityInfo.packageName, it.activityInfo.name)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                .sortedBy { it.label.lowercase() }
            ui.post { apps = list; (grid.adapter as BaseAdapter).notifyDataSetChanged() }
        }
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); grid.smoothScrollToPosition(0) }
    @Deprecated("") override fun onBackPressed() {} // الرئيسية لا تُغلق

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int) = apps[p]
        override fun getItemId(p: Int) = p.toLong()

        override fun getView(p: Int, v: View?, parent: ViewGroup): View {
            val app = apps[p]
            val cell = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(ImageView(context).apply { layoutParams = LinearLayout.LayoutParams(dp(60), dp(60)) })
                addView(TextView(context).apply {
                    setTextColor(Color.WHITE); textSize = 11f; maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                    setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
                    setPadding(0, dp(5), 0, 0)
                })
            }
            val img = cell.getChildAt(0) as ImageView
            (cell.getChildAt(1) as TextView).text = app.label
            img.tag = app.pkg
            val hit = cache.get(app.pkg)
            if (hit != null) img.setImageBitmap(hit) else {
                img.setImageDrawable(null)
                pool.execute {
                    val d = packageManager.getApplicationIcon(app.pkg)
                    val bmp = IconMasker.render(d, dp(60))
                    cache.put(app.pkg, bmp)
                    ui.post { if (img.tag == app.pkg) img.setImageBitmap(bmp) }
                }
            }
            return cell
        }
    }
}
