package com.example.iosl

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var store: Store
    private var apps = listOf<App>()
    private var byKey = mapOf<String, App>()
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = LruCache<String, Bitmap>(300)

    private lateinit var root: FrameLayout
    private lateinit var pager: Pager
    private lateinit var dock: LinearLayout
    private lateinit var dots: Dots
    private var overlay: View? = null

    private var insetTop = 0
    private var insetBottom = 0
    private var rows = 6
    private val cols = 4
    private val cap: Int get() = cols * rows
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val order = listOf(
        "التواصل الاجتماعي", "ترفيه وإبداع", "الإنتاجية",
        "سفر وخرائط", "أخبار وقراءة", "ألعاب", "أدوات"
    )

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r.toFloat()
        return g
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val f = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        window.setFlags(f, f)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        store = Store(this)
        insetTop = dp(28)
        insetBottom = dp(16)
        rows = ((resources.displayMetrics.heightPixels - dp(200)) / dp(92)).coerceIn(4, 6)

        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR

        pager = Pager(this)
        root.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))

        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.weightSum = 4f
        dock.background = rounded(Color.argb(85, 255, 255, 255), dp(30))
        dock.setPadding(dp(8), 0, dp(8), 0)
        val dlp = FrameLayout.LayoutParams(MATCH, dp(84), Gravity.BOTTOM)
        dlp.leftMargin = dp(14); dlp.rightMargin = dp(14); dlp.bottomMargin = insetBottom + dp(10)
        root.addView(dock, dlp)

        dots = Dots(this)
        val tlp = FrameLayout.LayoutParams(MATCH, dp(14), Gravity.BOTTOM)
        tlp.bottomMargin = insetBottom + dp(10) + dp(84) + dp(8)
        root.addView(dots, tlp)

        pager.onPage = { p -> dots.set(pager.pageCount(), p) }
        pager.onScroll = { x, w ->
            val n = pager.pageCount()
            if (w > 0 && n >= 2) {
                val a = (1f - (x - (n - 2) * w).toFloat() / w).coerceIn(0f, 1f)
                dock.alpha = a
                dock.visibility = if (a <= 0.02f) View.INVISIBLE else View.VISIBLE
            }
        }

        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = maxOf(ins.systemWindowInsetTop, dp(24))
            val bt = maxOf(ins.systemWindowInsetBottom, dp(8))
            if (t != insetTop || bt != insetBottom) {
                insetTop = t
                insetBottom = bt
                if (apps.isNotEmpty()) render()
            }
            ins
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    override fun onStart() {
        super.onStart()
        val fl = IntentFilter()
        fl.addAction(Intent.ACTION_PACKAGE_ADDED)
        fl.addAction(Intent.ACTION_PACKAGE_REMOVED)
        fl.addAction(Intent.ACTION_PACKAGE_CHANGED)
        fl.addDataScheme("package")
        registerReceiver(pkgReceiver, fl)
        loadApps()
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (overlay != null) closeOverlay() else goPage(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay != null) closeOverlay() else goPage(0)
    }

    private fun goPage(i: Int) {
        pager.smoothScrollTo(i * pager.width, 0)
        dots.set(pager.pageCount(), i)
    }

    // ---------------------------------------------------------------- data

    private fun loadApps() {
        pool.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val cls = ri.activityInfo.name
                    App(
                        pkg + "/" + cls, pkg, ri.loadLabel(pm).toString(),
                        ri.activityInfo.applicationInfo.category,
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(pkg, cls)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    )
                }
                .sortedBy { it.label.lowercase() }
            ui.post {
                val same = list.map { it.key } == apps.map { it.key }
                apps = list
                byKey = list.associateBy { it.key }
                if (!same || pager.pageCount() == 0) {
                    store.reconcile(byKey.keys, list.map { it.key }, if (store.fresh) defaultDock() else emptyList(), cap)
                    render()
                }
            }
        }
    }

    private fun defaultDock(): List<String> {
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val out = ArrayList<String>()
        for (i in intents) {
            val pkg = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName ?: continue
            val a = apps.firstOrNull { it.pkg == pkg } ?: continue
            if (a.key !in out) out.add(a.key)
        }
        return out
    }

    private fun group(a: App): String = when (a.category) {
        ApplicationInfo.CATEGORY_SOCIAL -> "التواصل الاجتماعي"
        ApplicationInfo.CATEGORY_GAME -> "ألعاب"
        ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_IMAGE -> "ترفيه وإبداع"
        ApplicationInfo.CATEGORY_NEWS -> "أخبار وقراءة"
        ApplicationInfo.CATEGORY_MAPS -> "سفر وخرائط"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "الإنتاجية"
        else -> "أدوات"
    }

    // ---------------------------------------------------------------- icons

    private fun bitmapFor(app: App, cb: (Bitmap) -> Unit) {
        val hit = cache.get(app.key)
        if (hit != null) { cb(hit); return }
        pool.execute {
            val d = try { packageManager.getActivityIcon(app.intent) } catch (e: Exception) { packageManager.defaultActivityIcon }
            val bmp = IconMasker.render(d, dp(60))
            cache.put(app.key, bmp)
            ui.post { cb(bmp) }
        }
    }

    private fun bindIcon(iv: IconView, app: App) {
        bitmapFor(app) { b -> iv.bmp = b; iv.invalidate() }
    }

    // ---------------------------------------------------------------- cells

    private fun label(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 11f
        tv.maxLines = 1
        tv.gravity = Gravity.CENTER
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setShadowLayer(4f, 0f, 1f, Color.argb(150, 0, 0, 0))
        tv.setPadding(dp(2), dp(5), dp(2), 0)
        return tv
    }

    private fun pressAnim(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    private fun appCell(app: App, showLabel: Boolean, size: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = if (showLabel) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else Gravity.CENTER
        c.setPadding(0, dp(6), 0, 0)
        val iv = IconView(this)
        bindIcon(iv, app)
        c.addView(iv, LinearLayout.LayoutParams(dp(size), dp(size)))
        if (showLabel) c.addView(label(app.label), LinearLayout.LayoutParams(MATCH, WRAP))
        c.setOnClickListener { launch(app, iv) }
        c.setOnLongClickListener { showAppMenu(app, c); true }
        pressAnim(c)
        return c
    }

    private fun folderCell(e: Entry): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        c.setPadding(0, dp(6), 0, 0)
        val iv = IconView(this)
        iv.folder = true
        e.keys.take(9).forEachIndexed { i, k ->
            val a = byKey[k]
            if (a != null) bitmapFor(a) { b -> iv.minis[i] = b; iv.invalidate() }
        }
        c.addView(iv, LinearLayout.LayoutParams(dp(60), dp(60)))
        c.addView(label(e.name ?: ""), LinearLayout.LayoutParams(MATCH, WRAP))
        c.setOnClickListener {
            openOverlay(e.name ?: "", e.keys.mapNotNull { byKey[it] }, e)
        }
        c.setOnLongClickListener { showFolderMenu(e, c); true }
        pressAnim(c)
        return c
    }

    // ---------------------------------------------------------------- render

    private fun render() {
        val keep = pager.currentPage()
        val sw = resources.displayMetrics.widthPixels
        val padT = insetTop + dp(14)
        val padB = insetBottom + dp(10) + dp(84) + dp(30)

        pager.row.removeAllViews()
        for (p in store.pages) {
            val page = HomePage(this, cols, rows)
            page.setPadding(dp(8), padT, dp(8), padB)
            for (e in p) {
                val cell: View? = if (e.isFolder) {
                    folderCell(e)
                } else {
                    val a = byKey[e.keys[0]]
                    if (a != null) appCell(a, true, 60) else null
                }
                if (cell != null) page.addView(cell)
            }
            pager.row.addView(page, LinearLayout.LayoutParams(sw, MATCH))
        }
        pager.row.addView(buildLibrary(padT, padB), LinearLayout.LayoutParams(sw, MATCH))

        dock.removeAllViews()
        for (k in store.dock) {
            val a = byKey[k] ?: continue
            dock.addView(appCell(a, false, 60), LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        val dlp = dock.layoutParams as FrameLayout.LayoutParams
        dlp.bottomMargin = insetBottom + dp(10)
        dock.layoutParams = dlp
        val tlp = dots.layoutParams as FrameLayout.LayoutParams
        tlp.bottomMargin = insetBottom + dp(10) + dp(84) + dp(8)
        dots.layoutParams = tlp

        val n = pager.pageCount()
        val cur = keep.coerceAtMost(n - 1)
        dots.set(n, cur)
        pager.post { pager.scrollTo(cur * sw, 0) }
    }

    // ---------------------------------------------------------------- library

    private fun buildLibrary(padT: Int, padB: Int): View {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        sv.setBackgroundColor(Color.argb(120, 0, 0, 0))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), padT, dp(16), padB)
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        val search = EditText(this)
        search.hint = "مكتبة التطبيقات"
        search.setHintTextColor(Color.argb(170, 255, 255, 255))
        search.setTextColor(Color.WHITE)
        search.textSize = 16f
        search.setSingleLine()
        search.background = rounded(Color.argb(90, 255, 255, 255), dp(14))
        search.setPadding(dp(16), dp(10), dp(16), dp(10))
        val slp = LinearLayout.LayoutParams(MATCH, WRAP)
        slp.bottomMargin = dp(16)
        col.addView(search, slp)

        val cards = LinearLayout(this)
        cards.orientation = LinearLayout.VERTICAL
        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        results.visibility = View.GONE
        col.addView(cards, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(results, LinearLayout.LayoutParams(MATCH, WRAP))

        val groups = apps.groupBy { group(it) }
        val names = order.filter { groups.containsKey(it) }
        var i = 0
        while (i < names.size) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (j in 0..1) {
                val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
                if (j == 0) lp.rightMargin = dp(7) else lp.leftMargin = dp(7)
                lp.bottomMargin = dp(14)
                if (i + j < names.size) {
                    val nm = names[i + j]
                    r.addView(card(nm, groups[nm] ?: emptyList()), lp)
                } else {
                    r.addView(View(this), lp)
                }
            }
            cards.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
            i += 2
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = (s?.toString() ?: "").trim().lowercase()
                results.removeAllViews()
                if (q.isEmpty()) {
                    cards.visibility = View.VISIBLE
                    results.visibility = View.GONE
                } else {
                    cards.visibility = View.GONE
                    results.visibility = View.VISIBLE
                    for (a in apps.filter { it.label.lowercase().contains(q) }.take(40)) {
                        results.addView(resultRow(a), LinearLayout.LayoutParams(MATCH, WRAP))
                    }
                }
            }
        })
        return sv
    }

    private fun card(title: String, list: List<App>): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.background = rounded(Color.argb(90, 255, 255, 255), dp(22))
        c.setPadding(dp(12), dp(14), dp(12), dp(10))
        val g = HomePage(this, 2, 2)
        for (a in list.take(4)) {
            val iv = IconView(this)
            iv.inset = dp(2).toFloat()
            bindIcon(iv, a)
            iv.setOnClickListener { launch(a, iv) }
            iv.setOnLongClickListener { showAppMenu(a, iv); true }
            g.addView(iv)
        }
        c.addView(g, LinearLayout.LayoutParams(dp(88), dp(88)))
        c.addView(label(title), LinearLayout.LayoutParams(MATCH, WRAP))
        c.setOnClickListener { openOverlay(title, list, null) }
        pressAnim(c)
        return c
    }

    private fun resultRow(a: App): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(6), 0, dp(6))
        val iv = IconView(this)
        bindIcon(iv, a)
        r.addView(iv, LinearLayout.LayoutParams(dp(46), dp(46)))
        val tv = TextView(this)
        tv.text = a.label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 16f
        val tlp = LinearLayout.LayoutParams(WRAP, WRAP)
        tlp.leftMargin = dp(14)
        r.addView(tv, tlp)
        r.setOnClickListener { launch(a, iv) }
        r.setOnLongClickListener { showAppMenu(a, r); true }
        return r
    }

    // ---------------------------------------------------------------- overlay (folders / categories)

    private fun openOverlay(title: String, list: List<App>, folder: Entry?) {
        closeOverlay()
        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.argb(140, 0, 0, 0))
        ov.setOnClickListener { closeOverlay() }

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = rounded(Color.argb(220, 58, 58, 64), dp(28))
        panel.setPadding(dp(10), dp(16), dp(10), dp(12))
        panel.isClickable = true

        val t = TextView(this)
        t.text = title
        t.setTextColor(Color.WHITE)
        t.textSize = 20f
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(0, 0, 0, dp(8))
        if (folder != null) {
            t.setOnClickListener {
                promptName(folder.name ?: "") { n ->
                    folder.name = n
                    store.save()
                    closeOverlay()
                    render()
                }
            }
        }
        panel.addView(t, LinearLayout.LayoutParams(MATCH, WRAP))

        val rws = ((list.size + cols - 1) / cols).coerceAtLeast(1)
        val g = HomePage(this, cols, rws)
        for (a in list) g.addView(appCell(a, true, 60))
        val full = rws * dp(92)
        val maxH = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(g, FrameLayout.LayoutParams(MATCH, full))
        panel.addView(sv, LinearLayout.LayoutParams(MATCH, minOf(full, maxH)))

        val plp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER)
        plp.leftMargin = dp(16); plp.rightMargin = dp(16)
        ov.addView(panel, plp)
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        overlay = ov

        ov.alpha = 0f
        panel.scaleX = 0.9f
        panel.scaleY = 0.9f
        ov.animate().alpha(1f).setDuration(140).start()
        panel.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    private fun closeOverlay() {
        val o = overlay
        if (o != null) root.removeView(o)
        overlay = null
    }

    // ---------------------------------------------------------------- actions

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (e: Exception) {
            Toast.makeText(this, "تعذر تنفيذ الأمر", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launch(app: App, v: View) {
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height)
            startActivity(app.intent, opts.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show()
        }
        closeOverlay()
    }

    private fun promptName(initial: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.setText(initial)
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("اسم المجلد")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) onOk(s)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showFolderMenu(e: Entry, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 0, 0, "إعادة تسمية")
        pm.menu.add(0, 1, 0, "تفكيك المجلد")
        pm.setOnMenuItemClickListener { item ->
            if (item.itemId == 0) {
                promptName(e.name ?: "") { n -> e.name = n; store.save(); render() }
            } else {
                store.dissolve(e, cap)
                render()
            }
            true
        }
        pm.show()
    }

    private fun showAppMenu(app: App, anchor: View) {
        val pm = PopupMenu(this, anchor)
        val acts = ArrayList<() -> Unit>()
        fun add(title: String, act: () -> Unit) {
            pm.menu.add(0, acts.size, 0, title)
            acts.add(act)
        }
        val k = app.key
        val inDock = k in store.dock
        val fold = store.folderOf(k)
        val isHidden = k in store.hidden

        if (inDock) {
            add("إزالة من الـ Dock") { store.removeFromDock(k, cap) }
        } else if (store.dock.size < 4) {
            add("إضافة إلى الـ Dock") { store.addToDock(k) }
        }
        if (fold != null) {
            add("إخراج من المجلد") { store.moveOut(k, cap) }
        } else if (!inDock && !isHidden) {
            add("إنشاء مجلد") { store.makeFolder(k, "مجلد", cap) }
            for (f in store.folders().take(6)) {
                add("نقل إلى «" + (f.name ?: "") + "»") { store.addToFolder(k, f) }
            }
        }
        if (isHidden) {
            add("إضافة إلى الشاشة الرئيسية") { store.unhide(k, cap) }
        } else {
            add("إزالة من الشاشة الرئيسية") { store.hide(k) }
        }
        add("معلومات التطبيق") {
            safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
        }
        add("إلغاء التثبيت") {
            safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
        }
        pm.setOnMenuItemClickListener { item ->
            acts[item.itemId]()
            closeOverlay()
            render()
            true
        }
        pm.show()
    }
}
